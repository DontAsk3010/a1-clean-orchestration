
"""Frozen V2 parity anchor extracted mechanically from the governed Colab notebook.

Analytical/data semantics are intentionally not redesigned here. Only environment-specific
Colab bootstrap/path concerns are injected through DataPlaneConfig so the same data-plane
logic can execute on a runner. Do not tune routing constants in this module.
"""
from .config import DataPlaneConfig

NOTEBOOK_CODE_SHA256 = "ba552f6d7f02f6c185c7cc28560f271db5976890f3b1ddc6d0dcfff132c4b868"

def run_delta(config: DataPlaneConfig, drive_api):
    from pathlib import Path
    from datetime import datetime, timezone
    import csv, hashlib, json, re, sqlite3, traceback, shutil, os
    GENERATION_ID=config.generation_id
    ENGINE_ROOT=config.engine_root
    RAW_DIR=config.raw_dir
    RUNTIME_INGEST_DIR=config.runtime_ingest_dir
    RAW_FOLDER_DRIVE_ID=config.raw_folder_drive_id
    RUN_ROOT=config.run_root
    DATA_PLANE_IMPL_VERSION=config.data_plane_impl_version
    MANIFEST_DIR=RUN_ROOT/'00_MANIFESTS'
    ACCESS_DIR=RUN_ROOT/'01_ACCESS_SHARDS'
    SEMANTIC_DIR=RUN_ROOT/'02_SEMANTIC_BUNDLES'
    MARKET_INDEX_DIR=RUN_ROOT/'03_MARKET_DAY_INDEX'
    CONTRACT_DIR=RUN_ROOT/'04_SEMANTIC_EVENT_CONTRACT'
    MAX_ACCESS_SHARD_BYTES=16*1024*1024
    MAX_SEMANTIC_BUNDLE_BYTES=6*1024*1024
    for p in [MANIFEST_DIR,ACCESS_DIR,SEMANTIC_DIR,MARKET_INDEX_DIR,CONTRACT_DIR]:
        p.mkdir(parents=True,exist_ok=True)
    assert RAW_DIR.exists(), f'RAW folder not found: {RAW_DIR}'
    print('GENERATION:',GENERATION_ID)
    print('RAW:',RAW_DIR)
    print('RUN:',RUN_ROOT)
    STATE_PATH=MANIFEST_DIR/'PERSISTENT_SOURCE_STATE.json'
    DELTA_PATH=MANIFEST_DIR/'LATEST_DELTA_REFRESH.json'
    AI_QUEUE_PATH=MANIFEST_DIR/'AI_SEMANTIC_DELTA_QUEUE.json'
    COVERAGE_INDEX_PATH=MANIFEST_DIR/'GLOBAL_SOURCE_COVERAGE_INDEX.json'
    print('PASS: persistent delta-aware runtime ready; canonical source untouched')


    # CELL 3 — GENERIC HELPERS / DATA BEBAS
    # There is NO allowed-field whitelist. Every physical field is retained.
    # Routing is discovered from the source and is separate from physical preservation.

    DT_PATTERNS=[
        '%Y-%m-%dT%H:%M:%S.%f','%Y-%m-%dT%H:%M:%S','%Y-%m-%dT%H:%M',
        '%Y-%m-%d %H:%M:%S.%f','%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%M',
        '%Y/%m/%d %H:%M:%S','%Y/%m/%d %H:%M',
        '%d-%m-%Y %H:%M:%S','%d-%m-%Y %H:%M',
        '%d/%m/%Y %H:%M:%S','%d/%m/%Y %H:%M'
    ]
    DATE_PATTERNS=['%Y-%m-%d','%Y/%m/%d','%d-%m-%Y','%d/%m/%Y','%Y%m%d']
    TIME_PATTERNS=['%H:%M:%S.%f','%H:%M:%S','%H:%M']

    def norm(x):
        return re.sub(r'[^a-z0-9]+','_',str(x).strip().lower()).strip('_')

    def parse_any(v,patterns):
        s=str(v).strip()
        for f in patterns:
            try: return datetime.strptime(s,f)
            except: pass
        try: return datetime.fromisoformat(s.replace('Z','+00:00'))
        except: return None

    def detect_header(header_bytes):
        last=None
        for enc in ['utf-8-sig','utf-8','cp1252','latin-1']:
            try:
                txt=header_bytes.decode(enc)
                dialect=csv.Sniffer().sniff(txt,delimiters=',;\t|')
                fields=next(csv.reader([txt.rstrip('\r\n')],dialect))
                if len(fields)>=1: return enc,dialect.delimiter,fields
            except Exception as e: last=e
        raise RuntimeError(f'HEADER_DETECT_FAILED: {last}')

    def sample_rows(path,enc,delim,n=300):
        out=[]
        with path.open('rb') as fh:
            fh.readline()
            for _ in range(n):
                raw=fh.readline()
                if not raw: break
                try: out.append(next(csv.reader([raw.decode(enc).rstrip('\r\n')],delimiter=delim)))
                except: pass
        return out

    def ratio(values,fn):
        good=total=0
        for v in values:
            s=str(v).strip()
            if not s: continue
            total+=1
            if fn(s): good+=1
        return good/total if total else 0.0

    def choose_unique(scores,minimum):
        ranked=sorted(enumerate(scores),key=lambda x:x[1],reverse=True)
        if not ranked or ranked[0][1] < minimum: return None,ranked[:5]
        if len(ranked)>1 and ranked[0][1]-ranked[1][1] < 0.02: return None,ranked[:5]
        return ranked[0][0],ranked[:5]

    def discover_routing(header,rows):
        nh=[norm(h) for h in header]
        def exact(name):
            m=[i for i,h in enumerate(nh) if h==name]
            return m[0] if len(m)==1 else None

        # Current canonical identity fields are preferred when actually present.
        # This is NOT a whitelist: unknown fields are still retained in full.
        ticker_idx=exact('raw_ticker')
        dt_idx=exact('raw_datetime_iso')
        date_idx=None
        time_idx=None
        ev={'exact':{},'content_inference':{}}
        if ticker_idx is not None: ev['exact']['ticker']='RAW_TICKER'
        if dt_idx is not None: ev['exact']['datetime']='RAW_DATETIME_ISO'

        valid=[r for r in rows if len(r)==len(header)]
        cols=list(zip(*valid)) if valid else []

        if ticker_idx is None and cols:
            scores=[ratio(c,lambda s: len(s)<=24 and bool(re.fullmatch(r'[A-Za-z0-9._-]+',s))) for c in cols]
            ticker_idx,rank=choose_unique(scores,0.90)
            ev['content_inference']['ticker_candidates']=rank

        if dt_idx is None and cols:
            ds=[ratio(c,lambda s: parse_any(s,DT_PATTERNS) is not None) for c in cols]
            dt_idx,rank=choose_unique(ds,0.95)
            ev['content_inference']['datetime_candidates']=rank

        if dt_idx is None and cols:
            ds=[ratio(c,lambda s: parse_any(s,DATE_PATTERNS) is not None) for c in cols]
            ts=[ratio(c,lambda s: parse_any(s,TIME_PATTERNS) is not None) for c in cols]
            date_idx,dr=choose_unique(ds,0.95)
            time_idx,tr=choose_unique(ts,0.95)
            ev['content_inference']['date_candidates']=dr
            ev['content_inference']['time_candidates']=tr

        return {
            'ticker_idx':ticker_idx,'datetime_idx':dt_idx,'date_idx':date_idx,'time_idx':time_idx,
            'routing_ready': ticker_idx is not None and (dt_idx is not None or date_idx is not None),
            'evidence':ev
        }

    def extract_date_time(fields,route):
        if route['datetime_idx'] is not None:
            x=parse_any(fields[route['datetime_idx']],DT_PATTERNS)
            if x: return x.strftime('%Y-%m-%d'),x.strftime('%H:%M:%S'),None
        if route['date_idx'] is not None:
            d=parse_any(fields[route['date_idx']],DATE_PATTERNS)
            if d:
                t=None
                if route['time_idx'] is not None:
                    tt=parse_any(fields[route['time_idx']],TIME_PATTERNS)
                    if tt: t=tt.strftime('%H:%M:%S')
                return d.strftime('%Y-%m-%d'),t,None
        return None,None,'ROUTING_TIME_UNRESOLVED'

    def segments(nums):
        if not nums:return []
        out=[];a=b=nums[0]
        for n in nums[1:]:
            if n==b+1:b=n
            else:out.append([a,b]);a=b=n
        out.append([a,b]);return out

    print('PASS: data-bebas helpers loaded')



    # CELL 4 — DISCOVER EVERY CURRENT CANONICAL SOURCE FILE
    # No month-name or filename-pattern gate. No column gate.

    def list_drive_files(folder_id):
        out=[];token=None
        q=f"'{folder_id}' in parents and trashed=false"
        while True:
            r=drive_api.files().list(q=q,fields='nextPageToken,files(id,name,mimeType,size,modifiedTime,parents)',pageSize=1000,pageToken=token,orderBy='name').execute()
            out+=r.get('files',[]);token=r.get('nextPageToken')
            if not token:break
        return [x for x in out if x.get('mimeType')!='application/vnd.google-apps.folder']

    drive_files=list_drive_files(RAW_FOLDER_DRIVE_ID)
    mounted={p.name:p for p in RAW_DIR.iterdir() if p.is_file()}
    DISCOVERY=[]
    for f in drive_files:
        p=mounted.get(f['name']);ds=int(f.get('size',-1)) if f.get('size') is not None else None;ls=p.stat().st_size if p else None
        DISCOVERY.append({
            'drive_file_id':f['id'],'name':f['name'],'mime_type':f.get('mimeType'),
            'drive_size_bytes':ds,'modified_time':f.get('modifiedTime'),'local_path':str(p) if p else None,'local_size_bytes':ls,
            'identity_state':'MATCH' if p and ds==ls else 'HOLD_IDENTITY_MISMATCH'
        })

    (MANIFEST_DIR/'GLOBAL_SOURCE_DISCOVERY.json').write_text(json.dumps({'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,'source_home_drive_id':RAW_FOLDER_DRIVE_ID,'files':DISCOVERY},indent=2,ensure_ascii=False),encoding='utf-8')
    for x in DISCOVERY:print(x['identity_state'],'|',x['name'],'|',x['mime_type'],'|',x['drive_file_id'],'|',x['drive_size_bytes'])
    assert DISCOVERY,'No current canonical source files found'
    assert all(x['identity_state']=='MATCH' for x in DISCOVERY),'HOLD: exact source identity mismatch'
    print('PASS: all current source identities matched')



    # CELL 5 — PHYSICAL LOSSLESS ACCESS FOR EVERY FILE
    # Reads ALL bytes. This stage does not care what fields mean.

    def physical_access(si):
        src=Path(si['local_path']);stem=src.stem
        h=hashlib.sha256();total=0;meta=[];i=0
        with src.open('rb') as fh:
            while True:
                data=fh.read(MAX_ACCESS_SHARD_BYTES)
                if not data:break
                i+=1;h.update(data);total+=len(data)
                p=ACCESS_DIR/f'{stem}__PHYSICAL_{i:04d}.bin'
                p.write_bytes(data)
                meta.append({'order_index':i,'name':p.name,'byte_count':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        return {
            'source_sha256':h.hexdigest(),'source_bytes_read':total,
            'physical_shard_count':len(meta),'physical_shards':meta,
            'physical_access_ready':total==src.stat().st_size
        }
    print('PASS: physical lossless access loaded')



    # CELL 6 — DYNAMIC ROUTING + COMPLETE TICKER-DAY EVIDENCE PACKETS
    # Unknown schema does NOT erase or reject the source. Physical access remains valid.

    def process_text_source(si,phys):
        src=Path(si['local_path']);stem=src.stem;sid=si['drive_file_id']
        res={
            'generation_id':GENERATION_ID,'source_name':src.name,'source_drive_id':sid,
            'source_size_bytes':src.stat().st_size,'source_sha256':phys['source_sha256'],
            'physical_access_ready':phys['physical_access_ready'],'physical_shard_count':phys['physical_shard_count'],
            'sampling_used':False,'filtering_used':False,'behavior_labels_created':False,'unknown_field_drop_allowed':False
        }
        try:
            with src.open('rb') as fh: header=fh.readline()
            enc,delim,hfields=detect_header(header)
            route=discover_routing(hfields,sample_rows(src,enc,delim,300))
            res.update(text_encoding=enc,delimiter=delim,header_fields=hfields,all_fields_preserved=True,routing=route)

            if not route['routing_ready']:
                res.update(status='PHYSICAL_ACCESS_READY_ROUTING_PENDING',next_stage='AI_OR_AUTHORITY_ROUTING_MAP_FROM_PRESERVED_RAW')
                return res

            db=config.scratch_dir/f"a1_{hashlib.sha1((src.name+GENERATION_ID).encode()).hexdigest()[:12]}.sqlite"
            db.unlink(missing_ok=True)
            con=sqlite3.connect(str(db));con.execute('PRAGMA journal_mode=OFF');con.execute('PRAGMA synchronous=OFF')
            con.execute('CREATE TABLE r(n INTEGER PRIMARY KEY,d TEXT,ticker TEXT,tm TEXT,raw BLOB)');con.execute('CREATE INDEX ix ON r(d,ticker,n)')
            total_rows=unresolved=0;batch=[];first_d=first_t=last_d=last_t=None
            with src.open('rb') as fh:
                original_header=fh.readline()
                for raw in fh:
                    total_rows+=1
                    try:
                        fields=next(csv.reader([raw.decode(enc).rstrip('\r\n')],delimiter=delim))
                        if len(fields)!=len(hfields): unresolved+=1;continue
                        d,t,e=extract_date_time(fields,route)
                        ticker=fields[route['ticker_idx']].strip() if route['ticker_idx'] is not None else ''
                        if e or not ticker: unresolved+=1;continue
                        if first_d is None:first_d,first_t=d,t
                        last_d,last_t=d,t
                        batch.append((total_rows,d,ticker,t,sqlite3.Binary(raw)))
                        if len(batch)>=5000:
                            con.executemany('INSERT INTO r VALUES (?,?,?,?,?)',batch);con.commit();batch=[]
                    except: unresolved+=1
                if batch:con.executemany('INSERT INTO r VALUES (?,?,?,?,?)',batch);con.commit()

            routed=con.execute('SELECT COUNT(*) FROM r').fetchone()[0]
            if unresolved:
                res.update(source_data_rows=total_rows,routed_rows=routed,unresolved_routing_rows=unresolved,status='PHYSICAL_ACCESS_READY_ROUTING_PARTIAL',next_stage='RESOLVE_ROUTING_FOR_ALL_ROWS_BEFORE_SEMANTIC_READING')
                con.close();db.unlink(missing_ok=True);return res

            groups=con.execute('SELECT d,ticker,COUNT(*),MIN(n),MAX(n),MIN(tm),MAX(tm) FROM r GROUP BY d,ticker ORDER BY d,ticker').fetchall()
            semantic_meta=[];daymap={};sem_sum=0;bundle_no=1
            bp=SEMANTIC_DIR/f'{stem}__SEMANTIC_{bundle_no:04d}.jsonl';bf=bp.open('wb');bbytes=0;bline=0
            header_text=original_header.decode(enc).rstrip('\r\n')
            def rotate(nxt):
                nonlocal bundle_no,bp,bf,bbytes,bline
                if bline>0 and bbytes+nxt>MAX_SEMANTIC_BUNDLE_BYTES:
                    bf.flush();bf.close();bundle_no+=1;bp=SEMANTIC_DIR/f'{stem}__SEMANTIC_{bundle_no:04d}.jsonl';bf=bp.open('wb');bbytes=0;bline=0

            for d,ticker,n,minr,maxr,mint,maxt in groups:
                rr=con.execute('SELECT n,raw FROM r WHERE d=? AND ticker=? ORDER BY n',(d,ticker)).fetchall();nums=[x[0] for x in rr];raws=[bytes(x[1]).decode(enc).rstrip('\r\n') for x in rr]
                rec={
                    'generation_id':GENERATION_ID,'source_drive_id':sid,'source_name':src.name,'source_sha256':phys['source_sha256'],
                    'trading_date':d,'ticker':ticker,'first_clock_time':mint,'last_clock_time':maxt,'data_row_count':n,
                    'source_row_first':minr,'source_row_last':maxr,'source_row_segments':segments(nums),
                    'raw_header':header_text,'raw_rows':raws,'all_source_columns_retained':True,
                    'semantic_reader_contract':{
                        'read_complete_ticker_day':True,'read_all_source_supported_sessions':True,
                        'do_not_filter_flat_weak_failure_no_event':True,'preserve_actual_event_clock_times':True,
                        'create_event_journey_objects_in_ai_not_python':True,'carry_open_journeys_across_dates':True
                    }
                }
                enc_rec=(json.dumps(rec,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8');rotate(len(enc_rec));line_no=bline+1;bf.write(enc_rec);bbytes+=len(enc_rec);bline+=1;sem_sum+=n
                ent={'trading_date':d,'ticker':ticker,'bundle_name':bp.name,'bundle_line_number':line_no,'data_row_count':n,'first_clock_time':mint,'last_clock_time':maxt,'source_row_first':minr,'source_row_last':maxr}
                semantic_meta.append(ent);daymap.setdefault(d,[]).append(ent)
            bf.flush();bf.close()

            (MANIFEST_DIR/f'{stem}__SEMANTIC_BUNDLES_MANIFEST.json').write_text(json.dumps(semantic_meta,indent=2,ensure_ascii=False),encoding='utf-8')
            mip=MARKET_INDEX_DIR/f'{stem}__MARKET_DAY_INDEX.json';mip.write_text(json.dumps({'generation_id':GENERATION_ID,'source_drive_id':sid,'source_name':src.name,'days':daymap},indent=2,ensure_ascii=False),encoding='utf-8')
            dates=con.execute('SELECT COUNT(DISTINCT d) FROM r').fetchone()[0];tickers=con.execute('SELECT COUNT(DISTINCT ticker) FROM r').fetchone()[0]
            con.close();db.unlink(missing_ok=True)
            ready=phys['physical_access_ready'] and sem_sum==total_rows==routed
            res.update(source_data_rows=total_rows,routed_rows=routed,unresolved_routing_rows=0,unique_trading_dates=dates,unique_tickers=tickers,ticker_day_objects=len(groups),semantic_ticker_day_row_sum=sem_sum,semantic_bundle_count=len(set(x['bundle_name'] for x in semantic_meta)),first_observed_date=first_d,first_observed_time=first_t,last_observed_date=last_d,last_observed_time=last_t,market_day_index=str(mip),status='ACCESS_READY_FOR_AI' if ready else 'HOLD_RECONCILIATION',next_stage='AI_SEMANTIC_BEHAVIOR_EVENT_JOURNEY_READING' if ready else 'FIX_RECONCILIATION')
            return res
        except Exception as e:
            res.update(status='PHYSICAL_ACCESS_READY_ROUTING_ERROR',hold_reason=repr(e),traceback=traceback.format_exc(limit=8),next_stage='INSPECT_PRESERVED_RAW_AND_FIX_ROUTING_WITHOUT_DROPPING_SOURCE')
            return res
    print('PASS: dynamic routing processor loaded')


    # UPDATE DATA / DELTA REFRESH — INCREMENTAL DRIVER
    # VERIFIED_UNCHANGED source files are reused without rereading source bytes.
    # NEW/CHANGED source files are fully processed. Removed sources purge only derivative runtime.

    def _load_json(p,default=None):
        try:return json.loads(Path(p).read_text(encoding='utf-8'))
        except:return default

    def _write_json(p,obj):
        p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
        t=Path(str(p)+'.tmp');t.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8');os.replace(t,p)

    def _manifest_path(name):return MANIFEST_DIR/f'{Path(name).stem}__DATA_PLANE_MANIFEST.json'
    def _semantic_manifest_path(name):return MANIFEST_DIR/f'{Path(name).stem}__SEMANTIC_BUNDLES_MANIFEST.json'
    def _market_index_path(name):return MARKET_INDEX_DIR/f'{Path(name).stem}__MARKET_DAY_INDEX.json'

    def _artifacts_exist(e):
        name=e.get('source_name','');stem=Path(name).stem
        if not _manifest_path(name).exists() or not _semantic_manifest_path(name).exists() or not _market_index_path(name).exists():return False
        ph=list(ACCESS_DIR.glob(f'{stem}__PHYSICAL_*.bin'));sb=list(SEMANTIC_DIR.glob(f'{stem}__SEMANTIC_*.jsonl'))
        ep=e.get('physical_shard_count');es=e.get('semantic_bundle_count')
        if ep is not None and len(ph)!=int(ep):return False
        if es is not None and len(sb)!=int(es):return False
        return bool(ph) and bool(sb)

    def _purge_derivative(name):
        stem=Path(name).stem
        for p in list(ACCESS_DIR.glob(f'{stem}__PHYSICAL_*.bin'))+list(SEMANTIC_DIR.glob(f'{stem}__SEMANTIC_*.jsonl'))+[_manifest_path(name),_semantic_manifest_path(name),_market_index_path(name)]:
            try:
                if p.exists():p.unlink()
            except:pass

    def _state_entry(r,modified_time):
        return {
          'source_drive_id':r.get('source_drive_id'),'source_name':r.get('source_name'),'source_size_bytes':r.get('source_size_bytes'),
          'source_modified_time':modified_time,'source_sha256':r.get('source_sha256'),'status':r.get('status'),
          'physical_shard_count':r.get('physical_shard_count'),'semantic_bundle_count':r.get('semantic_bundle_count'),
          'source_data_rows':r.get('source_data_rows'),'routed_rows':r.get('routed_rows'),'unresolved_routing_rows':r.get('unresolved_routing_rows'),
          'unique_trading_dates':r.get('unique_trading_dates'),'unique_tickers':r.get('unique_tickers'),'ticker_day_objects':r.get('ticker_day_objects'),
          'first_observed_date':r.get('first_observed_date'),'first_observed_time':r.get('first_observed_time'),
          'last_observed_date':r.get('last_observed_date'),'last_observed_time':r.get('last_observed_time'),
          'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,
          'accepted_at_utc':datetime.now(timezone.utc).isoformat()
        }

    prior_global=_load_json(MANIFEST_DIR/'GLOBAL_DATA_PLANE_MANIFEST.json',{}) or {}
    state_doc=_load_json(STATE_PATH,{'sources':{}}) or {'sources':{}}
    state=state_doc.get('sources',{})
    current_by_id={x['drive_file_id']:x for x in DISCOVERY}
    current_ids=set(current_by_id)

    # First V2 run bootstraps the just-verified V1 successful sources instead of rescanning them.
    boot=0
    if not state:
        prior_created=None
        try:prior_created=datetime.fromisoformat(str(prior_global.get('created_at_utc')).replace('Z','+00:00'))
        except:pass
        for r in prior_global.get('sources',[]):
            if r.get('status')!='ACCESS_READY_FOR_AI':continue
            sid=r.get('source_drive_id');cur=current_by_id.get(sid)
            if not cur:continue
            try:curmod=datetime.fromisoformat(str(cur.get('modified_time')).replace('Z','+00:00'))
            except:curmod=None
            if prior_created and curmod and curmod>prior_created:continue
            if int(cur.get('drive_size_bytes',-1))!=int(r.get('source_size_bytes',-2)):continue
            probe=_state_entry(r,cur.get('modified_time'))
            if not _artifacts_exist(probe):continue
            probe['bootstrap_from_prior_success']=True;state[sid]=probe;boot+=1

    removed_ids=set(state)-current_ids
    delta={
     'refresh_id':'DELTA_'+datetime.now().strftime('%Y%m%d_%H%M%S'),'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,
     'started_at_utc':datetime.now(timezone.utc).isoformat(),'bootstrap_source_count':boot,
     'verified_unchanged':[],'new_processed':[],'changed_rebuilt':[],'removed_purged':[],'replacement_same_content':[],'holds':[],'semantic_reopen_required':[]
    }

    for si in DISCOVERY:
        sid=si['drive_file_id'];old=state.get(sid)
        unchanged=False
        if old:
            unchanged=(old.get('source_name')==si['name'] and int(old.get('source_size_bytes',-1))==int(si['drive_size_bytes']) and old.get('source_modified_time')==si.get('modified_time') and old.get('status')=='ACCESS_READY_FOR_AI' and _artifacts_exist(old))
        if unchanged:
            delta['verified_unchanged'].append({'source_drive_id':sid,'source_name':si['name'],'source_sha256':old.get('source_sha256')})
            continue

        action='CHANGED' if old else 'NEW'
        # A changed source invalidates its prior derivative runtime before rebuild; RAW itself is never touched.
        if old:_purge_derivative(old['source_name'])
        else:_purge_derivative(si['name'])

        phys=physical_access(si)
        name=si['name'].lower();mime=(si.get('mime_type') or '').lower()
        is_text=name.endswith(('.csv','.tsv','.txt','.dat')) or 'csv' in mime or 'text' in mime
        if is_text:r=process_text_source(si,phys)
        else:r={'generation_id':GENERATION_ID,'source_name':si['name'],'source_drive_id':sid,'source_size_bytes':si['local_size_bytes'],'source_sha256':phys['source_sha256'],'physical_access_ready':phys['physical_access_ready'],'physical_shard_count':phys['physical_shard_count'],'all_fields_preserved':True,'sampling_used':False,'filtering_used':False,'behavior_labels_created':False,'status':'PHYSICAL_ACCESS_READY_ROUTING_PENDING','next_stage':'FORMAT_SPECIFIC_ROUTING_WITHOUT_SOURCE_LOSS'}
        r['data_plane_impl_version']=DATA_PLANE_IMPL_VERSION;r['source_modified_time']=si.get('modified_time')
        _write_json(_manifest_path(si['name']),r)

        if r.get('status')!='ACCESS_READY_FOR_AI':
            delta['holds'].append({'source_drive_id':sid,'source_name':si['name'],'action':action,'status':r.get('status'),'reason':r.get('hold_reason') or r.get('next_stage')})
            continue

        # Exact duplicate content is not admitted twice when both physical sources remain current.
        dup=None;replacement=None
        for osid,oe in list(state.items()):
            if osid==sid or oe.get('source_sha256')!=r.get('source_sha256'):continue
            if osid in current_ids:dup=oe;break
            if osid in removed_ids:replacement=oe
        if dup:
            _purge_derivative(si['name'])
            delta['holds'].append({'source_drive_id':sid,'source_name':si['name'],'action':'HOLD_DUPLICATE_SOURCE_CONTENT','duplicate_of_drive_id':dup.get('source_drive_id'),'duplicate_of_name':dup.get('source_name'),'sha256':r.get('source_sha256')})
            continue
        if replacement:
            oldid=replacement['source_drive_id'];_purge_derivative(replacement['source_name']);state.pop(oldid,None);removed_ids.discard(oldid)
            delta['replacement_same_content'].append({'old_drive_id':oldid,'old_name':replacement['source_name'],'new_drive_id':sid,'new_name':si['name'],'sha256':r.get('source_sha256')})

        state[sid]=_state_entry(r,si.get('modified_time'))
        rec={'source_drive_id':sid,'source_name':si['name'],'source_sha256':r.get('source_sha256'),'source_data_rows':r.get('source_data_rows'),'ticker_day_objects':r.get('ticker_day_objects'),'semantic_bundle_count':r.get('semantic_bundle_count')}
        (delta['new_processed'] if action=='NEW' else delta['changed_rebuilt']).append(rec)
        delta['semantic_reopen_required'].append({'source_drive_id':sid,'source_name':si['name'],'reason':action,'required_scope':'FULL_SOURCE_SEMANTIC_READ_PLUS_REQUIRED_BOUNDARY_CONTEXT'})

    # Source removed from canonical home => remove only derivative runtime so stale data cannot remain active.
    for sid in list(removed_ids):
        e=state.get(sid)
        if not e:continue
        _purge_derivative(e['source_name']);delta['removed_purged'].append({'source_drive_id':sid,'source_name':e['source_name']});state.pop(sid,None)

    ALL_RESULTS=[];coverage=[]
    for sid,e in sorted(state.items(),key=lambda z:z[1].get('source_name','')):
        r=_load_json(_manifest_path(e['source_name']),{}) or {}
        if r.get('status')!='ACCESS_READY_FOR_AI':continue
        r['data_plane_impl_version']=DATA_PLANE_IMPL_VERSION;r['source_modified_time']=e.get('source_modified_time')
        if any(x['source_drive_id']==sid for x in delta['new_processed']):r['delta_action']='NEW_PROCESSED'
        elif any(x['source_drive_id']==sid for x in delta['changed_rebuilt']):r['delta_action']='CHANGED_REBUILT'
        else:r['delta_action']='VERIFIED_UNCHANGED'
        ALL_RESULTS.append(r)
        coverage.append({'source_drive_id':sid,'source_name':e['source_name'],'source_sha256':e.get('source_sha256'),'first_observed_date':e.get('first_observed_date'),'first_observed_time':e.get('first_observed_time'),'last_observed_date':e.get('last_observed_date'),'last_observed_time':e.get('last_observed_time'),'source_data_rows':e.get('source_data_rows'),'ticker_day_objects':e.get('ticker_day_objects'),'market_day_index':str(_market_index_path(e['source_name']))})
    coverage.sort(key=lambda x:(x.get('first_observed_date') or '9999-99-99',x.get('first_observed_time') or '99:99:99',x.get('source_name') or ''))
    pos={x['source_drive_id']:i for i,x in enumerate(coverage)}
    for q in delta['semantic_reopen_required']:
        i=pos.get(q['source_drive_id'])
        if i is None:continue
        q['previous_source_context']=coverage[i-1]['source_name'] if i>0 else None
        q['next_source_context']=coverage[i+1]['source_name'] if i+1<len(coverage) else None
        q['boundary_rule']='Adjacent accepted source is reopened only as required RAW/context carry; unchanged source is not blindly reread in full.'

    semantic_gate='HOLD_DELTA_REQUIRES_REVIEW' if delta['holds'] else 'READY_FOR_AI_DELTA'
    _write_json(COVERAGE_INDEX_PATH,{'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,'sources_in_chronological_coverage_order':coverage})
    _write_json(AI_QUEUE_PATH,{'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,'created_at_utc':datetime.now(timezone.utc).isoformat(),'semantic_gate':semantic_gate,'full_semantic_sources':delta['semantic_reopen_required'],'removed_sources_invalidate_prior_semantic_objects':delta['removed_purged'],'cross_ticker_reconciliation_required':True,'cross_date_open_journey_carry_required':True,'cross_month_atlas_reconciliation_required':True,'unchanged_source_policy':'DO_NOT_FULL_REREAD; REOPEN ONLY REQUIRED BOUNDARY CONTEXT OR LINKED OPEN JOURNEY'})
    GLOBAL={'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,'created_at_utc':datetime.now(timezone.utc).isoformat(),'canonical_source_home_drive_id':RAW_FOLDER_DRIVE_ID,'runtime_root':str(RUN_ROOT),'sources':ALL_RESULTS,'delta_refresh_id':delta['refresh_id'],'delta_semantic_gate':semantic_gate,'physical_source_loss_allowed':False,'unknown_field_drop_allowed':False,'verified_unchanged_source_reuse':True,'new_changed_only_full_processing':True,'semantic_reader_status':'NOT_RUN_BY_THIS_NOTEBOOK','behavior_event_journey_pass_status':'NOT_EVALUATED_BY_THIS_NOTEBOOK'}
    _write_json(MANIFEST_DIR/'GLOBAL_DATA_PLANE_MANIFEST.json',GLOBAL)
    _write_json(STATE_PATH,{'state_version':1,'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,'updated_at_utc':datetime.now(timezone.utc).isoformat(),'sources':state})
    delta['finished_at_utc']=datetime.now(timezone.utc).isoformat();delta['semantic_gate']=semantic_gate;delta['active_source_count']=len(ALL_RESULTS);_write_json(DELTA_PATH,delta)

    print('\n=== UPDATE DATA / DELTA REFRESH RESULT ===')
    print('VERIFIED_UNCHANGED:',len(delta['verified_unchanged']))
    for x in delta['verified_unchanged']:print(' REUSE  |',x['source_name'])
    print('NEW_PROCESSED:',len(delta['new_processed']))
    for x in delta['new_processed']:print(' NEW    |',x['source_name'])
    print('CHANGED_REBUILT:',len(delta['changed_rebuilt']))
    for x in delta['changed_rebuilt']:print(' CHANGE |',x['source_name'])
    print('REMOVED_PURGED:',len(delta['removed_purged']))
    for x in delta['removed_purged']:print(' REMOVE |',x['source_name'])
    print('HOLDS:',len(delta['holds']))
    for x in delta['holds']:print(' HOLD   |',x['source_name'],'|',x.get('status') or x.get('action'))
    print('ACTIVE_SOURCE_COUNT:',len(ALL_RESULTS))
    print('SEMANTIC_GATE:',semantic_gate)
    print('STATUS:', 'PASS_NO_ACTIONABLE_SOURCE_DELTA' if not delta['new_processed'] and not delta['changed_rebuilt'] and not delta['removed_purged'] and not delta['holds'] else ('PASS_DELTA_READY_FOR_AI' if not delta['holds'] else 'HOLD_DELTA_REQUIRES_REVIEW'))



    # AI SEMANTIC EVENT/JOURNEY OUTPUT CONTRACT
    # This defines what the AI MUST write later. Python does not manufacture these events.
    EVENT_LIFECYCLE_FIELDS=[
        'JOURNEY_ID','EVENT_ID','PARENT_EVENT_ID_OR_LINKED_EVENT_ID','TICKER_OR_ENTITY_ID','TRADING_DATE',
        'SOURCE_FILE_ID','SOURCE_GENERATION_ID','SOURCE_RECORD_OR_RANGE_LINKS','SESSION_OR_MECHANISM','SOURCE_RESOLUTION',
        'PRECURSOR_WINDOW_START','PRECURSOR_START_TIME','FIRST_OBSERVED_TIME','EVENT_START_TIME','FIRST_DETECTABLE_TIME',
        'CHANGE_POINT_TIME','KNOWN_AT_TIME','CONFIRM_TIME','NON_CONFIRM_TIME','PEAK_TIME','TROUGH_TIME','EXTREME_TIME',
        'WEAKENING_TIME','FAIL_TIME','RECOVERY_TIME','REBASE_OR_TRANSFORMATION_TIME','INVALIDATION_TIME','EVENT_END_TIME',
        'LAST_OBSERVED_TIME','FOLLOW_THROUGH_END_TIME','PRIOR_CONDITION_AND_BASELINE','INITIATION_OR_CHANGE',
        'EFFORT_PARTICIPATION_PATH','PRICE_RESPONSE_OR_NON_RESPONSE','HIGH_LOW_DEVELOPMENT','PROGRESS_RETENTION_OR_GIVEBACK',
        'ACCELERATION_OR_DECELERATION','CONTINUATION_FAILURE_RECOVERY','POSITIVE_EVIDENCE','CONTRADICTION_FAILURE_EVIDENCE',
        'NEAR_TWIN_LOOKALIKE_LINKS','MARKET_SECTOR_REFERENCE_CONTEXT_IF_AVAILABLE','PROVEN_FLOW_MICROSTRUCTURE_IF_AVAILABLE',
        'MISSING_UNKNOWN_AVAILABILITY_STATE','CAUSAL_FIRST_DETECTABLE_VIEW','HINDSIGHT_COMPLETE_JOURNEY_VIEW',
        'OPEN_LEFT_RIGHT_CENSORED_STATE','UNRESOLVED_QUESTIONS'
    ]
    contract={
        'generation_id':GENERATION_ID,'data_plane_impl_version':DATA_PLANE_IMPL_VERSION,
        'rule':'AI derives behavior/event/journey semantics from preserved source chronology; Colab performs zero behavior pre-labeling.',
        'actual_event_clock_time_required':True,'timeframe_is_not_event_time':True,
        'event_lifecycle_fields':EVENT_LIFECYCLE_FIELDS,'unknown_behavior_allowed':'OBSERVED/UNNAMED/OPEN',
        'cross_ticker_reconciliation_required_before_date_close':True,'cross_date_open_journey_carry_required':True,
        'cross_month_atlas_required_after_source_envelope_pass':True,
        'source_event_family_policy':'Every additional provider/source event record physically present in the current canonical source home is preserved even when schema/semantics are unknown. Do not fabricate event/tick/L2/broker/foreign/corporate-action records that are not physically present/proven.'
    }
    cp=CONTRACT_DIR/'SEMANTIC_EVENT_JOURNEY_OUTPUT_CONTRACT.json';cp.write_text(json.dumps(contract,indent=2,ensure_ascii=False),encoding='utf-8')
    print('PASS: AI semantic event/journey contract written')
    print('Lifecycle fields:',len(EVENT_LIFECYCLE_FIELDS))
    print('Contract:',cp)

    return {'delta': delta, 'global_manifest': GLOBAL, 'semantic_gate': semantic_gate, 'contract_path': str(cp)}
